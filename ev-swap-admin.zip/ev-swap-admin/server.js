import express from "express";
import pkg from "pg";
import bodyParser from "body-parser";
import cors from "cors";
import path from "path";
import bcrypt from "bcrypt";
import { fileURLToPath } from "url";
import multer from "multer";
import XLSX from "xlsx";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const { Pool } = pkg;
const app = express();
const upload = multer({ dest: "uploads/" });

app.use(cors());
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "SignIn.html"));
});
app.get("/Controller", (req, res) => {
  res.sendFile(path.join(__dirname, "Controller.html"));
});
app.get("/Station", (req, res) => {
  res.sendFile(path.join(__dirname, "Station.html"));
});
app.get("/Battery", (req, res) => {
  res.sendFile(path.join(__dirname, "Battery.html"));
});
app.get("/CustomerManager", (req, res) => {
  res.sendFile(path.join(__dirname, "CustomerManager.html"));
});

app.get("/Feedback", (req, res) => {
  res.sendFile(path.join(__dirname, "Feedback.html"));
});

app.get("/ForgetPassword", (req, res) => {
  res.sendFile(path.join(__dirname, "ForgetPassword.html"));
});

// Sử dụng DATABASE_URL từ Heroku hoặc config local
const pool = new Pool({
  connectionString:
    process.env.DATABASE_URL ||
    "postgres://postgres:123@localhost:5432/doan_db",
  ssl: process.env.DATABASE_URL
    ? {
        rejectUnauthorized: false,
      }
    : false,
});

pool
  .connect()
  .then((client) => {
    console.log("Kết nối PostgreSQL thành công!");
    client.release();
  })
  .catch((err) => {
    console.error("Lỗi kết nối PostgreSQL:", err.message);
  });

app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password)
    return res
      .status(400)
      .json({ success: false, message: "Thiếu username hoặc password!" });

  try {
    const result = await pool.query(
      "SELECT * FROM admins WHERE username = $1",
      [username]
    );
    if (result.rows.length === 0)
      return res
        .status(401)
        .json({ success: false, code: 1, message: "Tài khoản không tồn tại!" });

    const user = result.rows[0];
    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword)
      return res
        .status(401)
        .json({ success: false, code: 2, message: "Mật khẩu không đúng!" });

    res.json({
      success: true,
      full_name: user.full_name,
      role: user.role,
      message: "Đăng nhập thành công!",
    });
  } catch (err) {
    console.error("Lỗi truy vấn dữ liệu:", err);
    res.status(500).json({ success: false, message: "Lỗi server!" });
  }
});

// Forgot Password - Check username
app.post("/forgot-password/check", async (req, res) => {
  const { username } = req.body;

  if (!username) {
    return res.status(400).json({
      success: false,
      message: "Vui lòng nhập tên đăng nhập!",
    });
  }

  try {
    const result = await pool.query(
      "SELECT username, full_name, role FROM admins WHERE username = $1 OR email = $1",
      [username]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Tài khoản không tồn tại trong hệ thống!",
      });
    }

    const user = result.rows[0];
    res.json({
      success: true,
      user: {
        username: user.username,
        full_name: user.full_name,
        role: user.role,
      },
    });
  } catch (err) {
    console.error("Lỗi kiểm tra tài khoản:", err);
    res.status(500).json({ success: false, message: "Lỗi server!" });
  }
});

// Forgot Password - Reset password
app.post("/forgot-password/reset", async (req, res) => {
  const { username, newPassword } = req.body;

  if (!username || !newPassword) {
    return res.status(400).json({
      success: false,
      message: "Thiếu thông tin cần thiết!",
    });
  }

  if (newPassword.length < 6) {
    return res.status(400).json({
      success: false,
      message: "Mật khẩu phải có ít nhất 6 ký tự!",
    });
  }

  try {
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    const result = await pool.query(
      "UPDATE admins SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE username = $2 RETURNING username",
      [hashedPassword, username]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Không thể cập nhật mật khẩu!",
      });
    }

    res.json({
      success: true,
      message: "Đặt lại mật khẩu thành công!",
    });
  } catch (err) {
    console.error("Lỗi đặt lại mật khẩu:", err);
    res.status(500).json({ success: false, message: "Lỗi server!" });
  }
});

app.post("/Controller", async (req, res) => {
  try {
    const query = `
      SELECT
      (SELECT COUNT(*) FROM stations) AS total_stations,
      (SELECT COUNT(*) AS total_active_stations FROM stations WHERE status = 'active') as ready_stations,
      (SELECT COUNT(*) FROM slots WHERE status = 'full' AND battery_uid IS NOT NULL) AS good_batteries,
      (SELECT COUNT(*) FROM batteries) AS total_batteries,
      (
          SELECT COUNT(*) 
          FROM customers 
          WHERE EXTRACT(MONTH FROM created_at) = EXTRACT(MONTH FROM CURRENT_DATE)
            AND EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM CURRENT_DATE)
      ) AS new_customers,
      (SELECT COUNT(*) AS maintenance_needed
      FROM stations
      WHERE status = 'maintenance') AS maintenance_needed ;

      `;

    const result = await pool.query(query);
    const data = result.rows[0];

    res.json({
      totalStations: parseInt(data.total_stations),
      readystations: parseInt(data.ready_stations),
      goodbatteries: parseInt(data.good_batteries),
      batteriesTotal: parseInt(data.total_batteries),
      newCustomers: parseInt(data.new_customers),
      maintenance: parseInt(data.maintenance_needed),
    });
  } catch (error) {
    console.error("Lỗi truy vấn dữ liệu:", error);
    res.status(500).json({ error: "Lỗi server" });
  }
});

app.get("/Controller/battery-by-station", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
          s.location AS station_name,
          COUNT(CASE WHEN sl.status = 'full' AND sl.battery_uid IS NOT NULL THEN 1 END) AS good_battery_count
      FROM stations s
      LEFT JOIN slots sl ON s.id = sl.station_id
      GROUP BY s.location
      ORDER BY s.location;
    `);

    res.json(result.rows);
  } catch (error) {
    console.error("Lỗi truy vấn pin theo trạm:", error);
    res.status(500).json({ error: "Lỗi server khi lấy dữ liệu pin theo trạm" });
  }
});

app.get("/Controller/battery-exchange-stats", async (req, res) => {
  try {
    const query = `
      SELECT
          s.location AS station_name,
          CASE 
              WHEN EXTRACT(MONTH FROM t.transaction_time) = 12 THEN 'December'
              ELSE 'Total (2025)'
          END AS period,
          COUNT(t.id) AS exchanged_batteries
      FROM transaction_logs t
      JOIN stations s ON t.station_id = s.id
      WHERE t.status = 'completed'
        AND EXTRACT(YEAR FROM t.transaction_time) = 2025
      GROUP BY s.location, EXTRACT(MONTH FROM t.transaction_time)
      ORDER BY s.location, period;
    `;

    const result = await pool.query(query);
    const stations = {};
    result.rows.forEach((row) => {
      const name = row.station_name;
      if (!stations[name])
        stations[name] = { station_name: name, December: 0, Total: 0 };
      if (row.period === "December") {
        stations[name].December = parseInt(row.exchanged_batteries);
        stations[name].Total += parseInt(row.exchanged_batteries);
      } else {
        stations[name].Total += parseInt(row.exchanged_batteries);
      }
    });

    const dataArray = Object.values(stations);

    res.json(dataArray);
  } catch (err) {
    console.error("Lỗi truy vấn:", err);
    res.status(500).json({ error: "Lỗi server khi lấy thống kê đổi pin" });
  }
});

app.get("/Station/table", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, location, status FROM stations ORDER BY id ASC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: "Database error" });
  }
});

app.get("/Station/edit/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const stationQuery = `SELECT * FROM stations WHERE id = $1`;
    const slotQuery = `SELECT id, slot_number, status, battery_uid FROM slots WHERE station_id = $1 ORDER BY slot_number`;
    const [stationRes, slotRes] = await Promise.all([
      pool.query(stationQuery, [id]),
      pool.query(slotQuery, [id]),
    ]);

    if (stationRes.rows.length === 0)
      return res.status(404).json({ error: "Không tìm thấy trạm" });
    const responseData = {
      ...stationRes.rows[0],
      slots: slotRes.rows,
    };

    res.json(responseData);
  } catch (err) {
    console.error("Lỗi lấy dữ liệu trạm:", err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

app.put("/Station/update/:id", async (req, res) => {
  try {
    const stationId = req.params.id;
    const {
      name,
      location,
      status,
      total_slots,
      available_slots,
      last_maintenance,
    } = req.body;

    const slotResult = await pool.query(
      `SELECT * FROM slots WHERE station_id = $1 ORDER BY slot_number ASC`,
      [stationId]
    );

    const currentSlots = slotResult.rows.length;
    const newTotal = parseInt(total_slots);

    if (newTotal < currentSlots) {
      const needDelete = currentSlots - newTotal;

      const emptySlots = slotResult.rows.filter((s) => s.status === "empty");

      if (emptySlots.length < needDelete) {
        return res.status(400).json({
          requireDelete: false,
          error: `Không đủ slot trống để xoá. Cần ${needDelete}, nhưng chỉ có ${emptySlots.length} slot empty`,
        });
      }

      return res.json({
        requireDelete: true,
        deleteCount: needDelete,
        emptySlots: emptySlots,
      });
    }

    const query = `
      UPDATE stations
      SET 
        name = $1,
        location = $2,
        status = $3,
        total_slots = $4,
        available_slots = $5,
        last_maintenance = $6
      WHERE id = $7
      RETURNING *;
    `;

    const values = [
      name,
      location,
      status,
      total_slots,
      available_slots,
      last_maintenance || null,
      stationId,
    ];

    const result = await pool.query(query, values);

    if (result.rowCount === 0) {
      return res
        .status(404)
        .json({ error: "Không tìm thấy trạm cần cập nhật" });
    }

    res.json({ message: "Cập nhật trạm thành công", station: result.rows[0] });
  } catch (err) {
    console.error("Lỗi khi cập nhật trạm:", err);
    res.status(500).json({ error: "Lỗi server khi cập nhật trạm" });
  }
});

app.post("/Slot/add", async (req, res) => {
  const { station_id } = req.body;

  try {
    const result = await pool.query(
      `SELECT COALESCE(MAX(slot_number), 0) + 1 AS next_number
             FROM slots WHERE station_id = $1`,
      [station_id]
    );

    const nextSlot = result.rows[0].next_number;

    await pool.query(
      `INSERT INTO slots (station_id, slot_number, status)
             VALUES ($1, $2, 'empty')`,
      [station_id, nextSlot]
    );

    res.json({ message: "Thêm slot thành công!", slot_number: nextSlot });
  } catch (err) {
    console.error("Error adding slot:", err);
    res.status(500).json({ error: "Lỗi server khi thêm slot" });
  }
});

app.delete("/Slot/delete/:id", async (req, res) => {
  const slotId = req.params.id;

  try {
    const slotCheck = await pool.query(`SELECT * FROM slots WHERE id = $1`, [
      slotId,
    ]);

    if (slotCheck.rowCount === 0) {
      return res.status(404).json({ error: "Slot không tồn tại" });
    }

    await pool.query(`DELETE FROM slots WHERE id = $1`, [slotId]);

    res.json({ message: "Xóa slot thành công!" });
  } catch (err) {
    console.error("Error deleting slot:", err);
    res.status(500).json({ error: "Lỗi server khi xoá slot" });
  }
});

app.post("/Station/add", async (req, res) => {
  const {
    name,
    location,
    status,
    total_slots,
    available_slots,
    last_maintenance,
  } = req.body;
  try {
    await pool.query(
      `INSERT INTO stations (name, location, status, total_slots, available_slots, last_maintenance)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        name,
        location,
        status,
        total_slots,
        available_slots,
        last_maintenance || null,
      ]
    );
    res.json({ success: true, message: "Thêm trạm mới thành công!" });
  } catch (err) {
    console.error("Lỗi thêm trạm:", err);
    res.status(500).json({ success: false, message: "Lỗi khi thêm trạm!" });
  }
});

app.delete("/Station/delete/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const check = await pool.query(
      `SELECT COUNT(*) AS busy
       FROM slots
       WHERE station_id = $1
       AND status != 'empty'`,
      [id]
    ); // check slot not empty

    const busy = parseInt(check.rows[0].busy);

    if (busy > 0) {
      return res.status(400).json({
        error: `Không thể xóa trạm vì còn 1 số điểm sạc/đổi Pin đang hoạt động!`,
      });
    }

    await pool.query(`DELETE FROM slots WHERE station_id = $1`, [id]);

    const result = await pool.query(
      `DELETE FROM stations WHERE id = $1 RETURNING *`,
      [id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Không tìm thấy trạm để xóa!" });
    }

    res.json({ message: "Xóa trạm thành công!" });
  } catch (err) {
    console.error("Lỗi khi xóa trạm:", err);
    res.status(500).json({ error: "Lỗi server khi xóa trạm!" });
  }
});

app.get("/Station/view/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const stationQuery = `
      SELECT * FROM stations WHERE id = $1;
    `;
    const slotQuery = `
      SELECT id, slot_number, status, battery_uid
      FROM slots 
      WHERE station_id = $1
      ORDER BY slot_number;
    `;

    const [stationRes, slotRes] = await Promise.all([
      pool.query(stationQuery, [id]),
      pool.query(slotQuery, [id]),
    ]);

    if (stationRes.rows.length === 0) {
      return res.status(404).json({ error: "Không tìm thấy trạm" });
    }

    const responseData = {
      ...stationRes.rows[0],
      slots: slotRes.rows,
    };

    res.json(responseData);
  } catch (err) {
    console.error("Lỗi lấy chi tiết trạm:", err);
    res.status(500).json({ error: "Lỗi server khi lấy chi tiết trạm" });
  }
});

app.get("/Battery/table", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT * FROM batteries ORDER BY uid ASC
    `);

    res.json(result.rows);
  } catch (err) {
    console.error("Lỗi lấy danh sách pin:", err);
    res.status(500).json({ error: "Lỗi server!" });
  }
});

app.get("/Battery/next-uid", async (req, res) => {
  try {
    const result = await pool.query(`
            SELECT uid 
            FROM batteries
            ORDER BY CAST(SUBSTRING(uid, 4) AS INTEGER) DESC
            LIMIT 1;
        `);

    let nextUid = "BAT001";

    if (result.rows.length > 0) {
      const lastUid = result.rows[0].uid;
      const number = parseInt(lastUid.slice(3));
      nextUid = "BAT" + String(number + 1).padStart(3, "0");
    }

    res.json({ nextUid });
  } catch (err) {
    console.error("Lỗi tạo UID:", err);
    res.status(500).json({ error: "Không thể tạo UID mới" });
  }
});

app.post("/Battery/add", async (req, res) => {
  try {
    const { uid, status, charge_cycles, last_charged } = req.body;

    const query = `
            INSERT INTO batteries (uid, status, charge_cycles, last_charged)
            VALUES ($1, $2, $3, $4)
            RETURNING *;
        `;

    const values = [uid, status, charge_cycles, last_charged || null];

    const result = await pool.query(query, values);

    res.json({ message: "Thêm pin thành công!", battery: result.rows[0] });
  } catch (err) {
    console.error("Lỗi thêm pin:", err);
    if (err.code === "23505") {
      return res
        .status(400)
        .json({ error: "Mã UID đã tồn tại. Vui lòng nhập mã khác!" });
    }

    res.status(500).json({ error: "Lỗi server khi thêm pin" });
  }
});

app.post("/Battery/import", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "Không có file!" });

    const workbook = XLSX.readFile(req.file.path);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet);

    let inserted = 0;
    let skipped = 0;

    for (const row of rows) {
      const { uid, status, charge_cycles, last_charged } = row;

      const check = await pool.query(
        "SELECT uid FROM batteries WHERE uid = $1",
        [uid]
      );

      if (check.rowCount > 0) {
        skipped++;
        continue;
      }

      await pool.query(
        `INSERT INTO batteries(uid, status, charge_cycles, last_charged)
                 VALUES($1,$2,$3,$4)`,
        [uid, status, charge_cycles || 0, last_charged || null]
      );

      inserted++;
    }

    res.json({
      message: "Import thành công!",
      inserted,
      skipped,
    });
  } catch (err) {
    console.error("Import error:", err);
    res.status(500).json({ error: "Lỗi server khi import file!" });
  }
});

app.get("/CustomerManager/table", async (req, res) => {
  try {
    const result = await pool.query(`
            SELECT 
                c.id,
                c.full_name,
                c.email,
                c.phone,
                c.current_battery_uid,
                c.total_swaps,
                c.created_at
            FROM customers c;
        `);

    res.json(result.rows);
  } catch (err) {
    console.error("Lỗi lấy danh sách khách hàng:", err);
    res.status(500).json({ error: "Lỗi server!" });
  }
});

app.get("/Feedback/table", async (req, res) => {
  try {
    const result = await pool.query(`
            SELECT 
                f.feedback_id,
                c.full_name,
                f.content,
                f.rating,
                f.feedback_date
            FROM feedback f
            JOIN customers c ON f.customer_id = c.id
            ORDER BY f.feedback_date DESC;

        `);

    res.json(result.rows);
  } catch (err) {
    console.error("Lỗi lấy danh sách phản hồi:", err);
    res.status(500).json({ error: "Lỗi server!" });
  }
});

app.get("/CustomerManager/view", async (req, res) => {
  try {
    const sql = `
            SELECT 
                r.id,
                c.full_name,
                s.name AS station_name,
                r.battery_uid,
                r.status,
                r.reserved_time,
                r.created_at,
                r.updated_at
            FROM reservations r
            JOIN customers c ON r.customer_id = c.id
            JOIN stations s ON r.station_id = s.id
            ORDER BY r.reserved_time DESC
        `;

    const result = await pool.query(sql);
    res.json(result.rows);
  } catch (err) {
    console.log("Lỗi load reservations:", err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
