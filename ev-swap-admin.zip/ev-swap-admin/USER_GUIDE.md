# HƯỚNG DẪN SỬ DỤNG HỆ THỐNG SV-CHARGE

## Mục lục

1. [Đăng nhập hệ thống](#1-đăng-nhập-hệ-thống)
2. [Dashboard - Bảng điều khiển](#2-dashboard---bảng-điều-khiển)
3. [Quản lý trạm sạc](#3-quản-lý-trạm-sạc)
4. [Quản lý pin](#4-quản-lý-pin)
5. [Quản lý khách hàng](#5-quản-lý-khách-hàng)
6. [Quản lý phản hồi](#6-quản-lý-phản-hồi)
7. [Tips và Tricks](#7-tips-và-tricks)

---

## 1. Đăng nhập hệ thống

### Bước 1: Truy cập trang đăng nhập

- Mở trình duyệt và truy cập: `http://localhost:3000`
- Hệ thống sẽ hiển thị trang đăng nhập

### Bước 2: Nhập thông tin đăng nhập

**Tài khoản mặc định:**

- **Email:** `superadmin@gmail.com`
- **Password:** `Admin123`

**Các tài khoản khác:**

- `admin1@gmail.com` / `Admin123`
- `admin2@gmail.com` / `Admin123`

### Bước 3: Nhấn "Đăng nhập"

- Nếu thông tin đúng: Chuyển đến trang Dashboard
- Nếu sai: Hiển thị thông báo lỗi màu đỏ

### Lưu ý:

- Mật khẩu phân biệt chữ hoa/thường
- Kiểm tra kết nối internet
- Đảm bảo server đang chạy

---

## 2. Dashboard - Bảng điều khiển

### Tổng quan

Dashboard hiển thị các thông tin quan trọng về hệ thống:

#### A. Thẻ thống kê (Cards)

**1. Tổng Số Trạm Sạc (Card xanh lá)**

- Số lượng: Tổng số trạm trong hệ thống
- Chi tiết: Số trạm đang hoạt động

**2. Pin Sẵn Sàng (Card vàng)**

- Số lượng: Pin trạng thái "good" trong kho
- Chi tiết: Tổng số pin trong hệ thống

**3. Khách Hàng Mới (Card xanh dương)**

- Số lượng: KH đăng ký trong tháng hiện tại
- Chi tiết: "Trong tháng"

**4. Cần Bảo Trì (Card đỏ)**

- Số lượng: Trạm có status = "maintenance"
- Chi tiết: "Trạm"

#### B. Biểu đồ phân tích

**Biểu đồ 1: Số Pin Sẵn Sàng Theo Trạm**

- Loại: Biểu đồ cột (Bar Chart)
- Mục đích: So sánh số lượng pin good giữa các trạm
- Màu sắc: Gradient xanh lá

**Biểu đồ 2: Tỷ Lệ Pin Sẵn Sàng Theo Trạm**

- Loại: Biểu đồ tròn (Doughnut Chart)
- Mục đích: Xem tỷ lệ phân bổ pin
- Màu sắc: Đa dạng theo trạm

**Biểu đồ 3: Số Pin Được Trao Đổi**

- Loại: Biểu đồ cột có filter tháng
- Tùy chọn: Tháng 11, Tháng 12, All
- Mục đích: Theo dõi hoạt động đổi pin

**Biểu đồ 4: Tỷ Lệ Pin Được Trao Đổi**

- Loại: Biểu đồ tròn theo tháng
- Cập nhật: Theo filter của biểu đồ 3

### Cách sử dụng

1. Xem tổng quan qua 4 cards
2. Phân tích chi tiết qua biểu đồ
3. Sử dụng filter tháng để so sánh

---

## 3. Quản lý trạm sạc

### A. Xem danh sách trạm

**Bước 1:** Click "Charging Station Management" trong menu bên trái

**Bước 2:** Xem thông tin trong bảng:

- **Mã trạm:** ID duy nhất
- **Tên:** Tên trạm (VD: STATION_01)
- **Địa điểm:** Vị trí (VD: PTIT Ha Noi)
- **Trạng thái:**
  - 🟢 Active (Hoạt động)
  - ⚪ Inactive (Ngưng hoạt động)
  - 🟠 Maintenance (Bảo trì)
- **Thao tác:** View, Edit, Delete

### B. Thêm trạm mới

**Bước 1:** Click nút "Thêm trạm mới" (góc trên bên phải)

**Bước 2:** Điền thông tin vào form:

- **Tên trạm:** Nhập tên (bắt buộc, không trùng)
- **Địa điểm:** Nhập địa chỉ chi tiết
- **Trạng thái:** Chọn active/inactive/maintenance
- **Tổng số khay:** Nhập số (mặc định 6)
- **Số khay trống:** Nhập số (≤ tổng số khay)
- **Lần bảo trì cuối:** Chọn ngày (tùy chọn)

**Bước 3:** Click "Lưu"

**Lưu ý:**

- Tên trạm phải duy nhất
- Số khay trống không được lớn hơn tổng số khay
- Hệ thống tự động tạo slots tương ứng

### C. Chỉnh sửa trạm

**Bước 1:** Click icon 🖊️ (Edit) ở cột Thao tác

**Bước 2:** Form hiện lên với dữ liệu sẵn

**Bước 3:** Chỉnh sửa thông tin cần thiết

**Bước 4:** Click "Lưu"

**Trường hợp đặc biệt - Giảm số khay:**

- Hệ thống kiểm tra xem có đủ slot trống để xóa không
- Nếu không đủ: Hiển thị cảnh báo
- Nếu đủ: Yêu cầu xác nhận xóa slot

**Ví dụ:**

```
Trạm có 8 slots, muốn giảm xuống 6 slots
→ Cần 2 slots trống
→ Nếu chỉ có 1 slot trống: Báo lỗi
→ Nếu có 2+ slots trống: Cho phép xóa
```

### D. Xóa trạm

**Bước 1:** Click icon 🗑️ (Delete) ở cột Thao tác

**Bước 2:** Xác nhận xóa trong popup

**Điều kiện:**

- ✅ Tất cả slots phải ở trạng thái "empty"
- ❌ Nếu có slot đang hoạt động: Báo lỗi

**Cách xử lý nếu không xóa được:**

1. Vào trang "View" của trạm
2. Xóa từng slot có pin
3. Quay lại xóa trạm

### E. Xem chi tiết trạm

**Bước 1:** Click icon 👁️ (View)

**Bước 2:** Xem thông tin:

- Thông tin chung trạm
- Danh sách tất cả slots

**Bước 3:** Quản lý slots:

**Thêm slot:**

1. Click "Thêm Slot"
2. Hệ thống tự động tạo slot với số thứ tự tiếp theo

**Xóa slot:**

1. Click "Xóa" bên cạnh slot
2. Chỉ xóa được slot trống (empty)

**Bước 4:** Click "Quay lại" để về danh sách

### F. Thông tin Slot

Mỗi slot hiển thị:

- **Số thứ tự:** 1, 2, 3...
- **Trạng thái:**
  - Empty: Trống
  - Full: Đầy (có pin đầy)
  - Charging: Đang sạc
  - Maintenance: Bảo trì
- **Mã pin:** UID của pin (nếu có)
- **Thao tác:** Nút Xóa (chỉ với slot empty)

---

## 4. Quản lý pin

### A. Xem danh sách pin

**Bước 1:** Click "Battery Management" trong menu

**Bước 2:** Xem thông tin trong bảng:

- **UID:** Mã pin duy nhất (VD: BAT001)
- **Trạng thái:**
  - 🟢 Good: Pin tốt
  - 🟡 Average: Pin trung bình
  - ⚫ Maintenance: Cần bảo trì
- **Mức sạc:** % (0-100)
- **Chu kỳ sạc:** Số lần sạc
- **Lần sạc cuối:** Thời gian
- **Ngày tạo:** Ngày thêm vào hệ thống

### B. Tìm kiếm và lọc

**Tìm kiếm theo UID:**

1. Nhập mã pin vào ô "Tìm kiếm pin..."
2. Kết quả tự động hiển thị

**Lọc theo trạng thái:**

1. Click dropdown "Chọn trạng thái"
2. Chọn: All / Good / Average / Maintenance
3. Bảng tự động lọc

**Kết hợp:**

- Có thể tìm kiếm + lọc cùng lúc
- VD: Tìm "BAT0" và lọc "Good"

### C. Thêm pin mới

**Bước 1:** Click nút "Thêm Pin Mới"

**Bước 2:** Form hiện lên với UID tự động (VD: BAT236)

**Bước 3:** Điền thông tin:

- **UID:** Tự động, có thể sửa
- **Trạng thái:** Chọn good/average/maintenance
- **Chu kỳ sạc:** Nhập số (mặc định 0)
- **Lần sạc cuối:** Chọn ngày giờ

**Bước 4:** Click "Thêm Pin"

**Lưu ý:**

- UID phải unique (không trùng)
- Format: BATxxx (3 chữ số)
- Mức sạc mặc định 100%

### D. Import pin từ Excel

**Bước 1:** Chuẩn bị file Excel

**Cấu trúc file .xlsx:**

| uid    | status  | charge_cycles | last_charged        |
| ------ | ------- | ------------- | ------------------- |
| BAT240 | good    | 0             | 2024-01-15 14:00:00 |
| BAT241 | average | 150           | 2024-01-14 10:00:00 |
| BAT242 | good    | 50            | 2024-01-15 10:30:00 |

**Bước 2:** Click nút "Import từ Excel"

**Bước 3:** Chọn file .xlsx từ máy

**Bước 4:** Click "Upload"

**Kết quả:**

```
Import thành công!
- Đã thêm: 15 pin
- Bỏ qua: 3 pin (UID trùng)
```

**Lưu ý:**

- File phải có đúng 4 cột theo thứ tự
- UID trùng sẽ tự động bỏ qua
- Dữ liệu sai format sẽ báo lỗi

### E. Xuất danh sách (Export)

**Bước 1:** Click nút "Xuất Excel"

**Bước 2:** File tự động download

**File chứa:**

- Tất cả pin trong hệ thống
- Tên file: `batteries_YYYY-MM-DD.xlsx`

---

## 5. Quản lý khách hàng

### A. Xem danh sách khách hàng

**Bước 1:** Click "Customer Management"

**Bước 2:** Xem thông tin:

- **Mã KH:** ID khách hàng
- **Tên:** Họ và tên
- **Email:** Địa chỉ email
- **Số điện thoại:** SĐT liên hệ
- **Pin hiện tại:** UID pin đang sử dụng
- **Tổng số lần đổi:** Lịch sử giao dịch

### B. Tìm kiếm khách hàng

**Cách 1: Tìm nhanh**

1. Nhập từ khóa vào ô "Tìm kiếm..."
2. Tìm được theo:
   - Tên khách hàng
   - Email
   - Số điện thoại

**Cách 2: Lọc nâng cao**

- Sắp xếp theo cột (click tiêu đề cột)
- Lọc theo số lần đổi pin

### C. Xem lịch hẹn đổi pin

**Bước 1:** Click nút "Lịch hẹn đổi Pin"

**Bước 2:** Xem bảng reservations:

- **Mã:** ID lịch hẹn
- **Khách hàng:** Tên người đặt
- **Trạm:** Trạm muốn đổi
- **Slot:** Khay đã đặt
- **Mã Pin:** Pin sẽ nhận
- **Trạng thái:**
  - Pending: Đang chờ
  - Confirmed: Đã xác nhận
  - Completed: Đã hoàn thành
  - Cancelled: Đã hủy
- **Thời gian đặt:** Khi nào đặt
- **Hết hạn:** Hạn xác nhận

**Bước 3:** Click "Quay lại" để về danh sách KH

### D. Phân tích khách hàng

**Khách hàng tích cực:**

- Số lần đổi > 20: Khách VIP
- Màu highlight đặc biệt

**Khách hàng mới:**

- Đăng ký trong tháng
- Icon "NEW" bên cạnh tên

---

## 6. Quản lý phản hồi

### A. Xem danh sách feedback

**Bước 1:** Click "Customer Feedback"

**Bước 2:** Xem bảng phản hồi:

- **Mã Phản Hồi:** ID duy nhất
- **Tên Khách hàng:** Người gửi
- **Nội dung:** Chi tiết feedback
- **Đánh giá:** 1-5 sao (⭐)
- **Ngày phản hồi:** Thời gian gửi

### B. Tìm kiếm và lọc

**Tìm theo tên:**

1. Nhập tên KH vào ô "Tìm tên khách hàng..."
2. Kết quả tự động lọc

**Lọc theo đánh giá:**

1. Click dropdown "Tất cả đánh giá"
2. Chọn: 1⭐ / 2⭐ / 3⭐ / 4⭐ / 5⭐
3. Hiển thị feedback theo rating

**Kết hợp:**

- Tìm tên + lọc rating
- VD: "Nguyễn" + "5⭐"

### C. Phân tích feedback

**Feedback tích cực (4-5 sao):**

- Màu xanh lá
- Nội dung tốt về dịch vụ

**Feedback tiêu cực (1-2 sao):**

- Màu đỏ
- Cần xem xét cải thiện

**Feedback trung lập (3 sao):**

- Màu vàng
- Cần chú ý

### D. Export báo cáo

**Bước 1:** Click "Xuất Báo Cáo"

**Bước 2:** Chọn loại:

- Tất cả feedback
- Chỉ 5 sao
- Chỉ 1-2 sao

**Bước 3:** File Excel tự động tải

---

## 7. Tips và Tricks

### A. Phím tắt

| Phím     | Chức năng      |
| -------- | -------------- |
| Ctrl + F | Tìm kiếm nhanh |
| Esc      | Đóng popup     |
| Enter    | Xác nhận form  |

### B. Thao tác nhanh

**Dashboard:**

- Click vào số liệu → Chuyển đến trang quản lý tương ứng
- Click biểu đồ → Xem chi tiết

**Trạm:**

- Double click dòng → Xem chi tiết
- Right click → Menu ngữ cảnh

**Pin:**

- Ctrl + Click nhiều dòng → Thao tác hàng loạt
- Shift + Click → Chọn vùng

### C. Best Practices

**1. Quản lý trạm:**

- Cập nhật status maintenance khi bảo trì
- Kiểm tra available_slots định kỳ
- Thêm note vào last_maintenance

**2. Quản lý pin:**

- Đánh dấu maintenance khi charge_cycles > 250
- Import hàng loạt tiết kiệm thời gian
- Export backup định kỳ

**3. Quản lý khách hàng:**

- Theo dõi total_swaps để ưu đãi VIP
- Xử lý feedback tiêu cực nhanh chóng
- Kiểm tra reservations hết hạn

### D. Xử lý sự cố

**Lỗi: "Không tìm thấy server"**

- Kiểm tra server có chạy không
- Restart: `node server.js`

**Lỗi: "Database connection failed"**

- Kiểm tra PostgreSQL đang chạy
- Verify thông tin kết nối

**Lỗi: "Không thể xóa trạm"**

- Kiểm tra slots còn pin
- Xóa slots trước, sau xóa trạm

**Lỗi: "Import file thất bại"**

- Kiểm tra format Excel
- Đảm bảo có đủ 4 cột
- Kiểm tra dữ liệu hợp lệ

### E. Bảo mật

**Đăng xuất:**

- Luôn logout sau khi sử dụng
- Không chia sẻ mật khẩu

**Phân quyền:**

- Super Admin: Toàn quyền
- Admin: CRUD trạm, pin, KH
- User: Chỉ xem

**Backup:**

- Backup database hàng ngày
- Export dữ liệu quan trọng

### F. Performance

**Tăng tốc:**

- Sử dụng filter thay vì scroll
- Đóng tab không dùng
- Clear cache trình duyệt

**Tối ưu:**

- Xóa dữ liệu cũ không cần
- Giữ số lượng pin ở mức hợp lý
- Archive khách hàng không hoạt động

---

## Câu hỏi thường gặp (FAQ)

**Q: Làm sao đổi mật khẩu?**
A: Hiện tại cần thông qua database. Tính năng UI sẽ có trong phiên bản sau.

**Q: Có thể khôi phục trạm đã xóa không?**
A: Không. Hãy backup trước khi xóa.

**Q: Số lượng pin tối đa mỗi slot?**
A: Mỗi slot có warehouse chứa tối đa 4 pin.

**Q: Làm sao xem lịch sử đổi pin của KH?**
A: Xem ở bảng transaction_logs trong database. UI đang phát triển.

**Q: Import file Excel bị lỗi encoding?**
A: Lưu file với encoding UTF-8.

---

**Phiên bản tài liệu:** 1.0.0  
**Ngày cập nhật:** 09/12/2025  
**Liên hệ hỗ trợ:** support@sv-charge.com
