# EV Swap Admin Web Interface

Web-based admin interface for managing the EV Battery Swap System.

## Deployment Information

- **Production URL**: https://ev-swap-admin-2025-8a16961f50e5.herokuapp.com/
- **Backend API**: https://ev-swap-backend-2025-b268b8b1f366.herokuapp.com
- **Database**: Shared PostgreSQL database with mobile backend

## Features

- Admin authentication and password reset
- Station management (view, add, edit, delete)
- Battery management (view, add, import from Excel)
- Controller dashboard with statistics
- Customer management and reservation tracking
- Feedback management

## Pages

- `/` - Sign In page
- `/Controller` - Dashboard with statistics
- `/Station` - Station management
- `/Battery` - Battery management
- `/CustomerManager` - Customer and reservation management
- `/Feedback` - Customer feedback
- `/ForgetPassword` - Password reset

## Technology Stack

- **Backend**: Express.js + Node.js
- **Database**: PostgreSQL (via pg driver)
- **Frontend**: Vanilla HTML/CSS/JavaScript
- **File Upload**: Multer
- **Excel Import**: XLSX, ExcelJS
- **Security**: bcrypt for password hashing

## Environment Variables

- `DATABASE_URL` - PostgreSQL connection string (shared with mobile backend)
- `PORT` - Server port (set by Heroku)

## Development

### Local Setup

```bash
npm install
node server.js
```

Server runs on http://localhost:3000

### Deploy to Heroku

```bash
# Login with API key
export HEROKU_API_KEY="your-heroku-api-key"

# Create Heroku app
heroku create your-app-name

# Set database URL (same as backend)
heroku config:set DATABASE_URL="your-database-url" --app your-app-name

# Deploy
git push heroku master
```

## Database Schema

Shares the same database schema as the mobile backend:

- `admins` - Admin users
- `stations` - Charging/swap stations
- `slots` - Station slots
- `batteries` - Battery inventory
- `customers` - Mobile app users
- `transaction_logs` - Swap transactions
- `reservations` - Customer reservations
- `feedback` - Customer feedback
- `warehouse` - Warehouse inventory
- `warehouse_batteries` - Batteries in warehouse

## API Endpoints

### Authentication

- `POST /login` - Admin login
- `POST /forgot-password/check` - Check username exists
- `POST /forgot-password/reset` - Reset password

### Controller Dashboard

- `POST /Controller` - Get dashboard statistics
- `GET /Controller/battery-by-station` - Get battery count by station
- `GET /Controller/battery-exchange-stats` - Get exchange statistics

### Station Management

- `GET /Station/table` - Get all stations
- `GET /Station/view/:id` - Get station details with slots
- `GET /Station/edit/:id` - Get station for editing
- `PUT /Station/update/:id` - Update station
- `POST /Station/add` - Add new station
- `DELETE /Station/delete/:id` - Delete station
- `POST /Slot/add` - Add slot to station
- `DELETE /Slot/delete/:id` - Delete slot

### Battery Management

- `GET /Battery/table` - Get all batteries
- `GET /Battery/next-uid` - Get next available UID
- `POST /Battery/add` - Add new battery
- `POST /Battery/import` - Import batteries from Excel

### Customer Management

- `GET /CustomerManager/table` - Get all customers
- `GET /CustomerManager/view` - Get all reservations

### Feedback

- `GET /Feedback/table` - Get all feedback with customer info

## Notes

- Uses ES6 modules (`"type": "module"` in package.json)
- Database connection uses SSL in production (Heroku)
- Uploads folder for Excel file import
- CORS enabled for cross-origin requests

## Maintenance

To view logs:

```bash
export HEROKU_API_KEY="your-api-key"
heroku logs --tail --app ev-swap-admin-2025
```

To restart:

```bash
heroku restart --app ev-swap-admin-2025
```
