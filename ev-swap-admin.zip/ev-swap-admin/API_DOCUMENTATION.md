# API DOCUMENTATION - SV-CHARGE SYSTEM

## Base URL

```
http://localhost:3000
```

## Authentication

### Login

**Endpoint:** `POST /login`

**Description:** Xác thực admin và lấy thông tin người dùng

**Request Body:**

```json
{
  "username": "superadmin@gmail.com",
  "password": "Admin123"
}
```

**Response Success (200):**

```json
{
  "success": true,
  "full_name": "Quản trị viên cấp cao",
  "role": "super_admin",
  "message": "Đăng nhập thành công!"
}
```

**Response Error (401):**

```json
{
  "success": false,
  "code": 1,
  "message": "Tài khoản không tồn tại!"
}
```

hoặc

```json
{
  "success": false,
  "code": 2,
  "message": "Mật khẩu không đúng!"
}
```

---

## Dashboard APIs

### Get Dashboard Statistics

**Endpoint:** `POST /Controller`

**Description:** Lấy thống kê tổng quan cho dashboard

**Response (200):**

```json
{
  "totalStations": 6,
  "readystations": 5,
  "goodbatteries": 150,
  "batteriesTotal": 235,
  "newCustomers": 10,
  "maintenance": 1
}
```

**Fields:**

- `totalStations`: Tổng số trạm
- `readystations`: Số trạm đang hoạt động (active)
- `goodbatteries`: Số pin tốt trong warehouse
- `batteriesTotal`: Tổng số pin trong hệ thống
- `newCustomers`: Số khách hàng mới đăng ký trong tháng hiện tại
- `maintenance`: Số trạm cần bảo trì

---

### Get Battery Count by Station

**Endpoint:** `GET /Controller/battery-by-station`

**Description:** Lấy số lượng pin tốt (good) tại mỗi trạm

**Response (200):**

```json
[
  {
    "station_name": "PTIT Ha Noi",
    "good_battery_count": 25
  },
  {
    "station_name": "BKDN Da Nang",
    "good_battery_count": 18
  }
]
```

---

### Get Battery Exchange Statistics

**Endpoint:** `GET /Controller/battery-exchange-stats`

**Description:** Thống kê số pin đã đổi trong tháng 12 và tổng năm 2025

**Response (200):**

```json
[
  {
    "station_name": "PTIT Ha Noi",
    "October": 5,
    "Total": 45
  },
  {
    "station_name": "BKDN Da Nang",
    "October": 3,
    "Total": 30
  }
]
```

---

## Station Management APIs

### Get All Stations

**Endpoint:** `GET /Station/table`

**Description:** Lấy danh sách tất cả các trạm

**Response (200):**

```json
[
  {
    "id": 1,
    "name": "STATION_01",
    "location": "PTIT Ha Noi",
    "status": "active"
  },
  {
    "id": 2,
    "name": "STATION_02",
    "location": "BKDN Da Nang",
    "status": "active"
  }
]
```

**Status values:**

- `active`: Hoạt động
- `inactive`: Ngưng hoạt động
- `maintenance`: Đang bảo trì

---

### Get Station for Edit

**Endpoint:** `GET /Station/edit/:id`

**Description:** Lấy thông tin chi tiết trạm để chỉnh sửa

**Parameters:**

- `id` (path): ID của trạm

**Response (200):**

```json
{
  "id": 1,
  "name": "STATION_01",
  "location": "PTIT Ha Noi",
  "status": "active",
  "total_slots": 6,
  "available_slots": 4,
  "last_maintenance": "2024-01-14T10:00:00.000Z",
  "created_at": "2024-01-01T00:00:00.000Z",
  "slots": [
    {
      "id": 1,
      "slot_number": 1,
      "status": "empty",
      "battery_uid": null
    },
    {
      "id": 2,
      "slot_number": 2,
      "status": "full",
      "battery_uid": "BAT004"
    }
  ]
}
```

---

### Update Station

**Endpoint:** `PUT /Station/update/:id`

**Description:** Cập nhật thông tin trạm

**Parameters:**

- `id` (path): ID của trạm

**Request Body:**

```json
{
  "name": "STATION_01",
  "location": "PTIT Ha Noi - Updated",
  "status": "active",
  "total_slots": 8,
  "available_slots": 6,
  "last_maintenance": "2024-01-15T10:00:00.000Z"
}
```

**Response Success (200):**

```json
{
  "message": "Cập nhật trạm thành công",
  "station": {
    "id": 1,
    "name": "STATION_01",
    "location": "PTIT Ha Noi - Updated",
    "status": "active",
    "total_slots": 8,
    "available_slots": 6
  }
}
```

**Response - Requires Slot Deletion (200):**

```json
{
  "requireDelete": true,
  "deleteCount": 2,
  "emptySlots": [
    {
      "id": 1,
      "slot_number": 1,
      "status": "empty"
    },
    {
      "id": 5,
      "slot_number": 5,
      "status": "empty"
    }
  ]
}
```

**Response Error (400):**

```json
{
  "requireDelete": false,
  "error": "Không đủ slot trống để xoá. Cần 3, nhưng chỉ có 2 slot empty"
}
```

---

### Add New Station

**Endpoint:** `POST /Station/add`

**Description:** Thêm trạm mới vào hệ thống

**Request Body:**

```json
{
  "name": "STATION_07",
  "location": "Hoa Lac, Ha Noi",
  "status": "active",
  "total_slots": 6,
  "available_slots": 6,
  "last_maintenance": null
}
```

**Response (200):**

```json
{
  "success": true,
  "message": "Thêm trạm mới thành công!"
}
```

---

### Delete Station

**Endpoint:** `DELETE /Station/delete/:id`

**Description:** Xóa trạm khỏi hệ thống

**Parameters:**

- `id` (path): ID của trạm

**Response Success (200):**

```json
{
  "message": "Xóa trạm thành công!"
}
```

**Response Error (400):**

```json
{
  "error": "Không thể xóa trạm vì còn 1 số điểm sạc/đổi Pin đang hoạt động!"
}
```

---

### View Station Details

**Endpoint:** `GET /Station/view/:id`

**Description:** Xem chi tiết trạm và danh sách slots

**Parameters:**

- `id` (path): ID của trạm

**Response (200):**

```json
{
  "id": 1,
  "name": "STATION_01",
  "location": "PTIT Ha Noi",
  "status": "active",
  "total_slots": 6,
  "available_slots": 4,
  "slots": [
    {
      "id": 1,
      "slot_number": 1,
      "status": "empty",
      "battery_uid": null
    },
    {
      "id": 2,
      "slot_number": 2,
      "status": "full",
      "battery_uid": "BAT004"
    }
  ]
}
```

---

## Slot Management APIs

### Add Slot

**Endpoint:** `POST /Slot/add`

**Description:** Thêm khay sạc mới cho trạm

**Request Body:**

```json
{
  "station_id": 1
}
```

**Response (200):**

```json
{
  "message": "Thêm slot thành công!",
  "slot_number": 7
}
```

---

### Delete Slot

**Endpoint:** `DELETE /Slot/delete/:id`

**Description:** Xóa khay sạc

**Parameters:**

- `id` (path): ID của slot

**Response (200):**

```json
{
  "message": "Xóa slot thành công!"
}
```

**Response Error (404):**

```json
{
  "error": "Slot không tồn tại"
}
```

---

## Battery Management APIs

### Get All Batteries

**Endpoint:** `GET /Battery/table`

**Description:** Lấy danh sách tất cả các pin

**Response (200):**

```json
[
  {
    "uid": "BAT001",
    "status": "average",
    "charge_level": 85,
    "charge_cycles": 120,
    "last_charged": "2024-01-15T10:30:00.000Z",
    "created_at": "2024-01-15T00:00:00.000Z"
  },
  {
    "uid": "BAT002",
    "status": "good",
    "charge_level": 100,
    "charge_cycles": 45,
    "last_charged": "2024-01-15T12:00:00.000Z",
    "created_at": "2024-01-15T00:00:00.000Z"
  }
]
```

**Battery Status:**

- `good`: Pin tốt
- `average`: Pin trung bình
- `maintenance`: Cần bảo trì

---

### Get Next Battery UID

**Endpoint:** `GET /Battery/next-uid`

**Description:** Lấy mã UID tiếp theo để tạo pin mới

**Response (200):**

```json
{
  "nextUid": "BAT236"
}
```

---

### Add New Battery

**Endpoint:** `POST /Battery/add`

**Description:** Thêm pin mới vào hệ thống

**Request Body:**

```json
{
  "uid": "BAT236",
  "status": "good",
  "charge_cycles": 0,
  "last_charged": "2024-01-15T14:00:00.000Z"
}
```

**Response (200):**

```json
{
  "message": "Thêm pin thành công!",
  "battery": {
    "uid": "BAT236",
    "status": "good",
    "charge_level": 100,
    "charge_cycles": 0,
    "last_charged": "2024-01-15T14:00:00.000Z"
  }
}
```

**Response Error (400):**

```json
{
  "error": "Mã UID đã tồn tại. Vui lòng nhập mã khác!"
}
```

---

### Import Batteries from Excel

**Endpoint:** `POST /Battery/import`

**Description:** Import nhiều pin từ file Excel

**Content-Type:** `multipart/form-data`

**Request:**

- Field name: `file`
- File type: `.xlsx`

**Excel Format:**
| uid | status | charge_cycles | last_charged |
|-----|--------|---------------|--------------|
| BAT240 | good | 0 | 2024-01-15 14:00:00 |
| BAT241 | average | 150 | 2024-01-14 10:00:00 |

**Response (200):**

```json
{
  "message": "Import thành công!",
  "inserted": 15,
  "skipped": 3
}
```

**Fields:**

- `inserted`: Số pin được thêm thành công
- `skipped`: Số pin bị bỏ qua (UID đã tồn tại)

---

## Customer Management APIs

### Get All Customers

**Endpoint:** `GET /CustomerManager/table`

**Description:** Lấy danh sách khách hàng

**Response (200):**

```json
[
  {
    "id": 1,
    "full_name": "Nguyễn Văn An",
    "email": "an.nguyen@email.com",
    "phone": "0901234567",
    "current_battery_uid": "BAT001",
    "total_swaps": 15,
    "created_at": "2024-01-01T00:00:00.000Z"
  },
  {
    "id": 2,
    "full_name": "Trần Thị Bình",
    "email": "binh.tran@email.com",
    "phone": "0901234568",
    "current_battery_uid": "BAT002",
    "total_swaps": 8,
    "created_at": "2024-01-05T00:00:00.000Z"
  }
]
```

---

### Get Customer Reservations

**Endpoint:** `GET /CustomerManager/view`

**Description:** Lấy danh sách lịch hẹn đổi pin

**Response (200):**

```json
[
  {
    "id": 1,
    "customer": "Nguyễn Văn An",
    "station": "STATION_01",
    "slot_id": 2,
    "battery_uid": "BAT004",
    "reservation_time": "2024-01-15T14:00:00.000Z",
    "expires_at": "2024-01-15T15:00:00.000Z",
    "status": "pending",
    "created_at": "2024-01-15T13:30:00.000Z"
  }
]
```

**Reservation Status:**

- `pending`: Đang chờ
- `confirmed`: Đã xác nhận
- `completed`: Đã hoàn thành
- `cancelled`: Đã hủy

---

## Feedback Management APIs

### Get All Feedback

**Endpoint:** `GET /Feedback/table`

**Description:** Lấy danh sách phản hồi từ khách hàng

**Response (200):**

```json
[
  {
    "feedback_id": 1,
    "full_name": "Nguyễn Văn An",
    "content": "Rất hài lòng với dịch vụ đổi pin. Pin mới hoạt động ổn định và nhân viên hỗ trợ nhiệt tình.",
    "rating": 5,
    "feedback_date": "2024-01-15T10:00:00.000Z"
  },
  {
    "feedback_id": 2,
    "full_name": "Trần Thị Bình",
    "content": "Trạm hơi đông vào giờ cao điểm nhưng đổi pin nhanh, nhân viên thân thiện.",
    "rating": 4,
    "feedback_date": "2024-01-15T11:30:00.000Z"
  }
]
```

**Rating:** Số nguyên từ 1 đến 5 (sao)

---

## Error Responses

### 400 Bad Request

```json
{
  "error": "Thiếu thông tin bắt buộc"
}
```

### 401 Unauthorized

```json
{
  "success": false,
  "message": "Tài khoản không tồn tại!"
}
```

### 404 Not Found

```json
{
  "error": "Không tìm thấy tài nguyên"
}
```

### 500 Internal Server Error

```json
{
  "error": "Lỗi server"
}
```

---

## Common HTTP Status Codes

| Code | Description                        |
| ---- | ---------------------------------- |
| 200  | OK - Request thành công            |
| 201  | Created - Tạo mới thành công       |
| 400  | Bad Request - Dữ liệu không hợp lệ |
| 401  | Unauthorized - Chưa xác thực       |
| 404  | Not Found - Không tìm thấy         |
| 500  | Internal Server Error - Lỗi server |

---

## Database Query Examples

### Get stations with good battery count

```sql
SELECT
    s.location AS station_name,
    COALESCE(COUNT(b.uid), 0) AS good_battery_count
FROM stations s
LEFT JOIN slots sl ON s.id = sl.station_id
LEFT JOIN warehouse w ON sl.id = w.slot_id
LEFT JOIN warehouse_batteries wb ON w.id = wb.warehouse_id
LEFT JOIN batteries b ON wb.battery_uid = b.uid AND b.status = 'good'
GROUP BY s.location
ORDER BY s.location;
```

### Get monthly transaction statistics

```sql
SELECT
    s.location AS station_name,
    CASE
        WHEN EXTRACT(MONTH FROM t.transaction_time) = 12 THEN 'October'
        ELSE 'Total (2025)'
    END AS period,
    COUNT(t.id) AS exchanged_batteries
FROM transaction_logs t
JOIN stations s ON t.station_id = s.id
WHERE t.status = 'completed'
  AND EXTRACT(YEAR FROM t.transaction_time) = 2025
GROUP BY s.location, ROLLUP(EXTRACT(MONTH FROM t.transaction_time))
ORDER BY s.location, period;
```

---

## Testing APIs with cURL

### Login

```bash
curl -X POST http://localhost:3000/login \
  -H "Content-Type: application/json" \
  -d '{"username":"superadmin@gmail.com","password":"Admin123"}'
```

### Get Dashboard Stats

```bash
curl -X POST http://localhost:3000/Controller \
  -H "Content-Type: application/json"
```

### Get All Stations

```bash
curl http://localhost:3000/Station/table
```

### Add New Battery

```bash
curl -X POST http://localhost:3000/Battery/add \
  -H "Content-Type: application/json" \
  -d '{
    "uid": "BAT240",
    "status": "good",
    "charge_cycles": 0,
    "last_charged": "2024-01-15T14:00:00.000Z"
  }'
```

### Delete Station

```bash
curl -X DELETE http://localhost:3000/Station/delete/7
```

---

**Document Version:** 1.0.0  
**Last Updated:** 09/12/2025
