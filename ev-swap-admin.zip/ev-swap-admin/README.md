# HỆ THỐNG QUẢN LÝ TRẠM SẠC VÀ ĐỔI PIN - SV-CHARGE

## TỔNG QUAN DỰ ÁN

**SV-Charge** là hệ thống quản lý trạm sạc và đổi pin điện tử dành cho xe máy điện, cho phép quản trị viên giám sát và vận hành mạng lưới các trạm sạc, quản lý pin, khách hàng và xử lý giao dịch đổi pin.

### Mục đích
- Quản lý hệ thống các trạm sạc pin điện tử
- Theo dõi trạng thái pin và khay sạc (slots)
- Quản lý khách hàng và lịch sử giao dịch đổi pin
- Cung cấp dashboard tổng quan cho quản trị viên
- Thu thập và phân tích phản hồi từ khách hàng

### Công nghệ sử dụng
- **Backend**: Node.js với Express.js
- **Database**: PostgreSQL
- **Frontend**: HTML, CSS, JavaScript thuần
- **Thư viện**:
  - Chart.js (biểu đồ)
  - Multer (upload file)
  - XLSX (xử lý file Excel)
  - Bcrypt (mã hóa mật khẩu)
  - CORS (xử lý cross-origin requests)

---

## CẤU TRÚC DỰ ÁN

```
DoAn/
├── server.js                    # Backend server chính
├── package.json                 # Dependencies và cấu hình npm
├── Database.sql                 # Schema và dữ liệu mẫu database
├── SignIn.html                  # Trang đăng nhập
├── Controller.html              # Dashboard tổng quan
├── Station.html                 # Quản lý trạm sạc
├── Battery.html                 # Quản lý pin
├── CustomerManager.html         # Quản lý khách hàng
├── Feedback.html               # Quản lý phản hồi khách hàng
├── ForgetPassword.html         # Trang quên mật khẩu
└── uploads/                    # Thư mục lưu file upload
```

---

## CƠ SỞ DỮ LIỆU

### Sơ đồ quan hệ (ERD)

Database gồm 9 bảng chính:

#### 1. **stations** - Quản lý trạm sạc
```sql
- id (PK): Mã trạm
- name: Tên trạm (unique)
- location: Địa điểm
- status: Trạng thái (active/inactive/maintenance)
- total_slots: Tổng số khay
- available_slots: Số khay trống
- last_maintenance: Lần bảo trì cuối
- created_at: Ngày tạo
```

#### 2. **batteries** - Thông tin pin
```sql
- uid (PK): Mã pin duy nhất
- status: Trạng thái (good/average/maintenance)
- charge_level: Mức sạc (0-100%)
- charge_cycles: Số chu kỳ sạc
- last_charged: Lần sạc cuối
- created_at: Ngày tạo
```

#### 3. **customers** - Khách hàng
```sql
- id (PK): Mã khách hàng
- full_name: Họ tên
- username: Tên đăng nhập
- password_hash: Mật khẩu đã mã hóa
- phone: Số điện thoại
- email: Email
- current_battery_uid (FK): Pin hiện đang dùng
- total_swaps: Tổng số lần đổi pin
- created_at: Ngày đăng ký
```

#### 4. **slots** - Khay sạc tại mỗi trạm
```sql
- id (PK): Mã khay
- station_id (FK): Thuộc trạm nào
- slot_number: Số thứ tự khay
- status: Trạng thái (empty/full/charging/maintenance)
- is_battery_present: Có pin hay không
- is_locked: Đã khóa chưa
- battery_uid (FK): Pin đang trong khay
- charge_level: Mức sạc hiện tại
- last_updated: Cập nhật lần cuối
```

#### 5. **admins** - Quản trị viên
```sql
- id (PK): Mã admin
- username: Tên đăng nhập
- password_hash: Mật khẩu đã mã hóa
- full_name: Họ tên
- role: Vai trò (super_admin/admin/user)
- created_at: Ngày tạo
```

#### 6. **transaction_logs** - Lịch sử giao dịch
```sql
- id (PK): Mã giao dịch
- customer_id (FK): Khách hàng
- station_id (FK): Trạm thực hiện
- request_type: Loại yêu cầu (swap/return)
- old_battery_uid (FK): Pin cũ
- slot_in: Khay trả pin cũ
- new_battery_uid (FK): Pin mới
- slot_out: Khay lấy pin mới
- transaction_time: Thời gian giao dịch
- completed_time: Thời gian hoàn thành
- status: Trạng thái (pending/completed/failed)
```

#### 7. **maintenance_logs** - Lịch sử bảo trì
```sql
- id (PK): Mã bảo trì
- station_id (FK): Trạm được bảo trì
- admin_id (FK): Admin thực hiện
- maintenance_type: Loại bảo trì
- description: Mô tả chi tiết
- start_time: Thời gian bắt đầu
- end_time: Thời gian kết thúc
- status: Trạng thái (in_progress/completed)
```

#### 8. **warehouse** - Kho chứa pin tại khay
```sql
- id (PK): Mã kho
- slot_id (FK): Thuộc khay nào
- total_capacity: Dung lượng tối đa (4 pin)
```

#### 9. **warehouse_batteries** - Pin trong kho
```sql
- id (PK): Mã bản ghi
- warehouse_id (FK): Thuộc kho nào
- battery_uid (FK): Mã pin
- inserted_at: Thời gian thêm vào
```

#### 10. **feedback** - Phản hồi khách hàng
```sql
- feedback_id (PK): Mã phản hồi
- customer_id (FK): Khách hàng
- content: Nội dung
- rating: Đánh giá (1-5 sao)
- feedback_date: Ngày gửi
```

### Triggers và Functions

1. **update_available_slots()**: Tự động cập nhật số khay trống khi thêm/sửa slot
2. **update_total_slots()**: Tự động cập nhật tổng số khay khi xóa slot

### Views

1. **station_overview**: Tổng quan trạm với thống kê khay
2. **battery_stats**: Thống kê pin theo trạng thái
3. **recent_transactions**: Giao dịch gần đây với thông tin chi tiết

---

## API ENDPOINTS

### Authentication
- `POST /login` - Đăng nhập admin

### Dashboard (Controller)
- `POST /Controller` - Lấy thống kê tổng quan
- `GET /Controller/battery-by-station` - Pin sẵn sàng theo trạm
- `GET /Controller/battery-exchange-stats` - Thống kê đổi pin theo tháng

### Station Management
- `GET /Station/table` - Danh sách trạm
- `GET /Station/edit/:id` - Chi tiết trạm để edit
- `GET /Station/view/:id` - Xem chi tiết trạm
- `PUT /Station/update/:id` - Cập nhật trạm
- `POST /Station/add` - Thêm trạm mới
- `DELETE /Station/delete/:id` - Xóa trạm

### Slot Management
- `POST /Slot/add` - Thêm khay sạc
- `DELETE /Slot/delete/:id` - Xóa khay sạc

### Battery Management
- `GET /Battery/table` - Danh sách pin
- `GET /Battery/next-uid` - Lấy UID pin tiếp theo
- `POST /Battery/add` - Thêm pin mới
- `POST /Battery/import` - Import pin từ file Excel

### Customer Management
- `GET /CustomerManager/table` - Danh sách khách hàng
- `GET /CustomerManager/view` - Lịch hẹn đổi pin

### Feedback Management
- `GET /Feedback/table` - Danh sách phản hồi

---

## GIAO DIỆN NGƯỜI DÙNG

### 1. SignIn.html - Trang đăng nhập
- Form đăng nhập với username/password
- Xác thực qua API `/login`
- Chuyển hướng đến Controller sau khi đăng nhập thành công
- Hiển thị lỗi nếu thông tin không đúng

**Tài khoản mặc định:**
- Email: `superadmin@gmail.com`
- Password: `Admin123`

### 2. Controller.html - Dashboard
**Chức năng:**
- 4 cards thống kê:
  - Tổng số trạm sạc và số trạm hoạt động
  - Pin sẵn sàng và tổng số pin
  - Khách hàng mới trong tháng
  - Trạm cần bảo trì
  
- Biểu đồ Bar Chart: Pin sẵn sàng theo từng trạm
- Biểu đồ Doughnut: Tỷ lệ pin sẵn sàng theo trạm
- Biểu đồ đổi pin: Thống kê theo tháng (có filter tháng)

### 3. Station.html - Quản lý trạm
**Chức năng:**
- Hiển thị danh sách trạm dạng bảng
- **Thêm trạm mới**: Form nhập thông tin
- **Sửa trạm**: Chỉnh sửa name, location, status, total_slots, available_slots
- **Xóa trạm**: Chỉ xóa được nếu không còn slot đang hoạt động
- **Xem chi tiết**: Hiển thị thông tin trạm và danh sách slots
- **Quản lý slots**: Thêm/xóa slot cho từng trạm

**Trạng thái trạm:**
- `active`: Hoạt động (màu xanh)
- `inactive`: Ngưng hoạt động (màu xám)
- `maintenance`: Đang bảo trì (màu cam)

### 4. Battery.html - Quản lý pin
**Chức năng:**
- Hiển thị danh sách pin với đầy đủ thông tin
- **Tìm kiếm**: Theo UID pin
- **Lọc**: Theo trạng thái (good/average/maintenance)
- **Thêm pin**: Tự động tạo UID tiếp theo
- **Import từ Excel**: Upload file .xlsx chứa nhiều pin

**Trạng thái pin:**
- `good`: Pin tốt (màu xanh lá)
- `average`: Pin trung bình (màu vàng)
- `maintenance`: Cần bảo trì (màu xám)

### 5. CustomerManager.html - Quản lý khách hàng
**Chức năng:**
- Hiển thị danh sách khách hàng
- Thông tin: Mã KH, tên, email, SĐT, pin hiện tại, số lần đổi pin
- **Tìm kiếm**: Theo tên, email, SĐT
- **Xem lịch hẹn đổi pin**: Danh sách các đặt chỗ (reservations)

### 6. Feedback.html - Quản lý phản hồi
**Chức năng:**
- Hiển thị danh sách feedback từ khách hàng
- **Tìm kiếm**: Theo tên khách hàng
- **Lọc**: Theo đánh giá (1-5 sao)
- Hiển thị: Mã phản hồi, tên KH, nội dung, đánh giá, ngày gửi

---

## CÀI ĐẶT VÀ CHẠY DỰ ÁN

### Yêu cầu hệ thống
- Node.js (v14+)
- PostgreSQL (v12+)
- npm hoặc yarn

### Bước 1: Cài đặt dependencies
```bash
cd DoAn
npm install
```

### Bước 2: Thiết lập database
1. Tạo database PostgreSQL:
```sql
CREATE DATABASE doan;
```

2. Import schema và dữ liệu:
```bash
psql -U postgres -d doan -f Database.sql
```

3. Cập nhật thông tin kết nối trong `server.js`:
```javascript
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'doan',
  password: 'your_password',  // Thay đổi password
  port: 5432,
});
```

### Bước 3: Chạy server
```bash
node server.js
```

Server sẽ chạy tại: `http://localhost:3000`

### Bước 4: Truy cập ứng dụng
Mở trình duyệt và truy cập:
```
http://localhost:3000
```

---

## TÍNH NĂNG CHI TIẾT

### Quản lý Trạm sạc

**Thêm trạm mới:**
1. Click "Thêm trạm mới"
2. Nhập thông tin: tên, địa điểm, trạng thái, số slot
3. Hệ thống tự động tạo các slot tương ứng

**Chỉnh sửa trạm:**
1. Click icon Edit (bút chì)
2. Sửa thông tin cần thiết
3. Nếu giảm total_slots: hệ thống kiểm tra xem có đủ slot trống để xóa không

**Xóa trạm:**
- Chỉ xóa được nếu tất cả slots đều ở trạng thái `empty`
- Hệ thống sẽ xóa tất cả slots liên quan trước khi xóa trạm

**Quản lý Slots:**
- Mỗi trạm có thể có 6-8 slots
- Mỗi slot có thể chứa tối đa 4 pin trong warehouse
- Trạng thái slot: empty, full, charging, maintenance

### Quản lý Pin

**Quy tắc đặt tên:**
- Format: `BATxxx` (ví dụ: BAT001, BAT002,...)
- Hệ thống tự động tạo UID tiếp theo

**Chu kỳ sống của pin:**
1. **good**: Pin mới hoặc còn tốt (charge_cycles < 150)
2. **average**: Pin suy giảm (150 ≤ charge_cycles < 250)
3. **maintenance**: Pin cần bảo trì (charge_cycles ≥ 250 hoặc lỗi)

**Import từ Excel:**
- Chuẩn bị file .xlsx với các cột: uid, status, charge_cycles, last_charged
- Upload file qua giao diện
- Hệ thống tự động skip các UID đã tồn tại

### Quản lý Khách hàng

**Thông tin theo dõi:**
- Thông tin cá nhân (họ tên, email, SĐT)
- Pin hiện đang sử dụng
- Tổng số lần đổi pin (total_swaps)
- Ngày đăng ký

**Lịch hẹn đổi pin:**
- Khách hàng có thể đặt trước slot tại trạm
- Theo dõi trạng thái: pending, confirmed, completed, cancelled

### Dashboard Analytics

**Metrics hiển thị:**
1. Tổng số trạm và số trạm hoạt động
2. Số pin sẵn sàng đổi (good batteries trong warehouse)
3. Số khách hàng mới đăng ký trong tháng
4. Số trạm cần bảo trì

**Biểu đồ:**
1. **Bar Chart**: Số lượng pin good trong warehouse của từng trạm
2. **Doughnut Chart**: Tỷ lệ phân bổ pin theo trạm
3. **Bar Chart tháng**: Số pin đã đổi trong tháng (có filter)
4. **Doughnut Chart tháng**: Tỷ lệ giao dịch theo trạm

---

## BẢO MẬT

### Mã hóa mật khẩu
- Sử dụng bcrypt với cost factor 10
- Password được hash trước khi lưu vào database
- So sánh hash khi đăng nhập

### Phân quyền
- **super_admin**: Toàn quyền
- **admin**: Quản lý trạm, pin, khách hàng
- **user**: Chỉ xem

### CORS
- Cho phép các request từ frontend
- Cấu hình trong server.js

---

## DỮ LIỆU MẪU

Database đã được tạo sẵn với:
- 6 trạm sạc tại Hà Nội và Đà Nẵng
- 235 pin với các trạng thái khác nhau
- 68 khách hàng
- 3 tài khoản admin
- 61 giao dịch đổi pin mẫu
- 5 feedback từ khách hàng
- Warehouse đầy đủ pin cho các slot

---

## XỬ LÝ LỖI THƯỜNG GẶP

### Lỗi kết nối Database
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```
**Giải pháp:**
- Kiểm tra PostgreSQL đã chạy chưa: `sudo service postgresql status`
- Kiểm tra thông tin kết nối trong server.js

### Lỗi Port đã được sử dụng
```
Error: listen EADDRINUSE: address already in use :::3000
```
**Giải pháp:**
- Đổi port trong server.js hoặc kill process đang dùng port 3000
```bash
lsof -ti:3000 | xargs kill -9
```

### Lỗi Import Excel
```
No file uploaded
```
**Giải pháp:**
- Đảm bảo thư mục `uploads/` tồn tại
- Kiểm tra format file Excel đúng chuẩn

---

## TƯƠNG LAI PHÁT TRIỂN

### Tính năng bổ sung
1. **Mobile App**: Ứng dụng cho khách hàng
2. **Real-time monitoring**: WebSocket để theo dõi trạng thái real-time
3. **Payment Integration**: Tích hợp thanh toán online
4. **Analytics nâng cao**: Machine Learning dự đoán nhu cầu
5. **Notification System**: Email/SMS thông báo cho khách hàng
6. **QR Code**: Quét mã QR để đổi pin
7. **Maps Integration**: Hiển thị trạm trên bản đồ
8. **Reporting**: Xuất báo cáo định kỳ

### Cải thiện kỹ thuật
1. Chuyển sang TypeScript
2. Sử dụng ORM (Sequelize/TypeORM)
3. Implement JWT authentication
4. Unit testing và Integration testing
5. Docker containerization
6. CI/CD pipeline
7. Load balancing cho nhiều server

---

## LIÊN HỆ VÀ HỖ TRỢ

Để được hỗ trợ hoặc đóng góp cho dự án, vui lòng:
- Tạo issue trên GitHub repository
- Email: support@sv-charge.com (nếu có)

---

## GIẤY PHÉP

Dự án này được phát triển cho mục đích học tập và nghiên cứu.

---

## CHANGELOG

### Version 1.0.0 (Current)
- Quản lý trạm sạc đầy đủ (CRUD)
- Quản lý pin và warehouse
- Dashboard với biểu đồ thống kê
- Quản lý khách hàng
- Hệ thống feedback
- Import pin từ Excel
- Authentication cơ bản

---

**Ngày tạo document:** 09/12/2025
**Phiên bản:** 1.0.0
**Tác giả:** SV-Charge Development Team
